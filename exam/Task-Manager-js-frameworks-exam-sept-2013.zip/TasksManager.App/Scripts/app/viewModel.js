﻿/// <reference path="../libs/_references.js" />
var todo = todo || {};

todo.viewModels = (function () {
    var data = todo.data.get("/api");
    var views = todo.views;

    var loginRegisterViewModel = kendo.observable({
        loginUsername: "",
        loginPassword: "",
        registerUsername: "",
        email: "",
        registerPassword: "",
        login: function () {
            var username = this.get("loginUsername");
            var password = this.get("loginPassword");
           
            return data.users.login(username, password)
                .then(function (userData) {
                    todo.viewModels.userProfileViewModel.set("username", userData.username);
                    todo.viewModels.userProfileViewModel.set("isLogged", true);
                    todo.ui.toggleNavigation("logged");
                    todo.router.navigate("/");
                },
                function (errorData) {
                    todo.ui.handleError(errorData);
                })
        },
        register: function () {
            return data.users
                .register(this.get("registerUsername"), this.get("registerPassword"), this.get("email"))
                .then(function () {
                    todo.router.navigate("/login");
                },
                function (errorData) {
                    todo.ui.handleError(errorData);
                })
        },
        logout: function () {
            data.users.logout(function () {
                todo.ui.toggleNavigation();
                todo.router.navigate("/");
            }, function (err) {
                todo.ui.handleError(errorData);
                (function () {
                    var yes;
                    prompt("Clear local data and login again? yes/no", yes);
                    if (yes) {
                        todo.ui.toggleNavigation();
                        todo.router.navigate("/");
                        return;
                    }
                }());
            });
            
        }
    });

    var userProfileViewModel = kendo.observable({
        isLogged: false,
        username: "Anonymous",
        init: function () {
            if (data.isUserLogged()) {
                this.set("isLogged", true);
                this.set("username", data.getUsername());
            }
        }
    });
    
    var appointmentsAll = kendo.observable({
        appointments: [],
        typeAppointment: ["All", "Comming", "Today", "Current"],
        typeIndex: 0,
        searchByDate: "",
        init: function () {
            var self = this;
            data.appointments.getAll()
                .then(function (result) {
                    self.set("appointments", result);
                }, todo.errorHandle)
        },
        getSelectedAppointments: function () {
            var self = this;

            var type = self.typeAppointment[parseInt(self.typeIndex)];

            switch (type) {
                case "Comming": {
                    data.appointments.comming()
                        .then(function (result) {
                            self.set("appointments", result);
                        },
                        todo.errorHandle);
                    break;
                }
                case "Today": {
                    data.appointments.today()
                        .then(function (result) {
                            self.set("appointments", result);
                        },
                        todo.errorHandle);
                    break;
                }
                case "Current": {
                    data.appointments.current()
                        .then(function (result) {
                            self.set("appointments", result);
                        },
                        todo.errorHandle);
                    break;
                }
                default: {
                    self.init();
                    break;
                }
            }
        },
        getAppointmentsByDate: function () {
            var self = this;
            var date = this.searchByDate.toString();

            data.appointments.getByDate(date)
                .then(function (result) {
                    self.set("appointments", result);
                }, todo.errorHandle)
        }
    });

    var newAppointmentViewModel = kendo.observable({
        message: "",
        subject: "",
        description: "",
        appointmentDate: "",
        duration: 30,
        createNew: function () {
            var self = this;

            var newApp = {
                subject: this.subject,
                description: this.description,
                appointmentDate: this.appointmentDate,
                duration: this.duration
            }

            data.appointments.create(newApp)
                .then(function () {
                    
                    self.set("subject", "");
                    self.set("description", "");
                    self.set("duration", 30);

                }, todo.errorHandle);

        }
    });

    var listsAllViewModel = kendo.observable({
        lists: [],
        init: function () {
            var self = this;
            data.lists.getAll()
                .then(function (result) {
                    self.set("lists", result);
                },
                todo.errorHandle);
        }
    });

    var createListViewModel = kendo.observable({
        title: "",
        todos: [],
        newText:"",
        addItem: function () {
            todos = this.get("todos");
            todos.push({
                text: this.newText
            });
            this.set("newText", "");
        },
        createList: function () {
            var list = {
                title: this.title,
                todos: this.todos,
            }

            var self = this;
            data.lists.create(list)
                .then(function (result) {
                    self.set("title", "");
                    self.set("todos", []);

                },
                todo.errorHandle)
        }

    })

    var singleListViewModel = kendo.observable({
        id:"",
        title: "",
        todoes: [],
        text: "",
        isDone:false,
        getList: function (id) {
            var self = this;
            self.set("id", id);
            data.lists.getById(id)
                .then(function (result) {
                    self.set("title", result.title);
                    self.set("todoes", result.todos);
                },
                todo.errorHandle);
        },
        addNew: function () {
            var newToDo = {
                text: this.text,
                isDone: this.isDone
            }

            var self = this;

            data.lists.addToDo(self.id, newToDo)
                .then(function (result) {
                    newToDo.id = result.id;
                    var todoes = self.get("todoes");
                    todoes.push(newToDo);
                    //self.set("todoes", todoes);
                },
                todo.errorHandle);
        },
        change: function (e) {
            var self = this;
            var todoId = $(e.currentTarget).data("todo-id");
            var span = $(e.target);
            data.todos.tickToggle(todoId)
                .then(function () {
                    var todoes = self.get("todoes");

                    var todo = _.where(todoes, { id: todoId }, true);
                    var status = todo.get("isDone");
                    todo.set("isDone", !status);

                    var text = span.text();
                    if (text == "Done!") {
                        span.text("Not done!");
                    }
                    else {
                        span.text("Done!");
                    }
                },
                todo.errorHandle)
        }
    });
    
    return {
        loginRegisterViewModel: loginRegisterViewModel,
        userProfileViewModel: userProfileViewModel,
        appointmentsAll: appointmentsAll,
        newAppointment: newAppointmentViewModel,
        listsAll: listsAllViewModel,
        singleList: singleListViewModel,
        createList: createListViewModel
    };
}());
    
  