﻿/// <reference path="../libs/_references.js" />
var todo = todo || {};
//todo.data = todo.data.getDataPersister("/api");

(function () {
    todo.router = new kendo.Router({
        init: function () {
            //todo.ui.toggleNavigation();
        }
    });

    var ui = todo.ui;
    var layout;
    var data = todo.data.get("/api");

    var errorHandle = function (err) {
        ui.handleError(err);
    }

    todo.errorHandle = errorHandle;

    var initLayout = function () {
        RSVP.all([todo.views.getLayout(), todo.views.getProfileBoxView()])
       .then(function (results) {
           // Initializes the layout
           layout = results[0];
           var profileBoxHtml = results[1];
           var profileBoxVM = todo.viewModels.userProfileViewModel;
           var profileBoxView = new kendo.View(profileBoxHtml, { model: profileBoxVM });

           profileBoxVM.init();

           layout.showIn("#profile-box", profileBoxView);
           layout.render('#application');

           todo.router.start();
       });
    }

    // #/ route
    todo.router.route("/", function () {
        var isLogged = todo.viewModels.userProfileViewModel.isLogged;
        if (!isLogged) {
            todo.router.navigate("/login");
        }
        else {
            todo.views.getHomeView()
                .then(function (homeHtml) {
                    var view = new kendo.View(homeHtml, {
                        model: kendo.observable({
                            data: "empty"
                        })
                    });
                    layout.showIn("#page", view);
                }, errorHandle);
        }
    })

    // logout home => /
    todo.router.route("/home", function () {
        todo.router.navigate("/");
    });

    // login route
    todo.router.route("/login", function () {        
        var loginVM = todo.viewModels.loginRegisterViewModel;
        todo.views.getLoginRegisterView()
        .then(function (loginViewHtml) {
            var view = new kendo.View(loginViewHtml, { model: loginVM });
            layout.showIn("#page", view);
        });
    });

    // logout route
    todo.router.route("/logout", function () {
        data.users.logout()
             .then(function () {
                 todo.viewModels.userProfileViewModel.set("email", "Not set");
                 todo.viewModels.userProfileViewModel.set("isLogged", false);
             });
        todo.ui.toggleNavigation();
        todo.router.navigate("/");
    });

    // appointments   route
    todo.router.route("/appointments", function () {
        todo.views.getAppointmentsAllView()
            .then(function (appointmentsAllHtml) {
                var appointmentsAllVM = todo.viewModels.appointmentsAll;
                appointmentsAllVM.init();

                var view = new kendo.View(appointmentsAllHtml, { model: appointmentsAllVM });
                layout.showIn("#page", view);
            },
            errorHandle);
    });

    // appointments/add  route 
    todo.router.route("/appointments/add", function () {
        todo.views.newAppointment()
            .then(function (newAppointmentHtml) {
                var newAppointmentVM = todo.viewModels.newAppointment;
                var view = new kendo.View(newAppointmentHtml, { model: newAppointmentVM });
                layout.showIn("#page", view);
            }, todo.errorHandle)
    });

    // todo-lists  route
    todo.router.route("/todo-lists", function () {
        todo.views.allLists()
            .then(function (listHtml) {
                var listsAllVM = todo.viewModels.listsAll;
                var view = new kendo.View(listHtml, { model: listsAllVM });
                listsAllVM.init();
                layout.showIn("#page", view);
            },
            errorHandle);
    });

    todo.router.route("/todo-lists/add", function () {
        todo.views.newList()
        .then(function (newListHtml) {
            var newListVM = todo.viewModels.createList;
            var view = new kendo.View(newListHtml, { model: newListVM });
            layout.showIn("#page", view);
        }, todo.errorHandle)
    })


    // todo-lists/:id route
    todo.router.route("/todo-lists/:id", function (id) {
        todo.views.singleList()
            .then(function (listHtml) {
                var singleListVM = todo.viewModels.singleList;
                singleListVM.getList(id);
                var view = new kendo.View(listHtml, { model: singleListVM });
                layout.showIn("#page", view);
            },
            todo.errorHandle)
    });


    $(function () {
        ui.init();
        initLayout();
    });
}());