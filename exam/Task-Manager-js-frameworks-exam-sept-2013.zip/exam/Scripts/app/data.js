﻿/// <reference path="../libs/_references.js" />
var todo = todo || {};

todo.data = (function () {    
    var requester = todo.requester;

    var saveUserData = function(user){
        localStorage.setItem("accessToken", user.accessToken);
        localStorage.setItem("username", user.username);
        localStorage.setItem("userId", user.id);
    }

    var clearUserData = function () {
        localStorage.removeItem("accessToken");
        localStorage.removeItem("username");
        localStorage.removeItem("userId");
    }

    var loadUserData = function(){
        sessionKey = localStorage.getItem("accessToken");
    }

    var getUsername = function(){
        return localStorage.getItem("username");
    }

    var getAccessToken = function () {
        return localStorage.getItem("accessToken");
    }

    var getUserId = function () {
        return localStorage.getItem("userId");
    }
    
    var isUserLogged = function(){
        var accessToken = getAccessToken();
        if (!accessToken) {
            return false;
        }
        return true;
    }

    var DataPersister = Class.create({
        init: function (baseUrl) {
            this.baseUrl = baseUrl;
            this.users = new UsersPersister(baseUrl);
            this.appointments = new AppointmentsPersister(baseUrl);
            this.lists = new ListsPersisiter(baseUrl);
            this.todos = new TodosPersisiter(baseUrl);
        },
        isUserLogged: function(){            
            return isUserLogged();
        },
        loadUserData:function(){
            loadUserData();
        },
        getUsername: function () {
            return getUsername();
        }
    });

    var UsersPersister = Class.create({
        init: function(baseUrl){
            this.baseUrl = baseUrl;
        },
        login: function(username, password){
            var user = {
                username: username,
                authCode: CryptoJS.SHA1(username + password).toString()
            }

            return requester.postJSON(this.baseUrl + "/auth/token", user)
                .then(function (result) {
                    saveUserData(result);
                    return result;
                });
        },
        register: function (username, password, email) {
            var user = {
                username: username,
                email: email,
                authCode: CryptoJS.SHA1(username + password).toString()
            }

            return requester.postJSON(this.baseUrl + "/users/register", user);
        },
        logout: function () { 
            var headers = {
                "X-accessToken": getAccessToken()
            }
            //clears the data in all cases - user wants to log out so we log him out
            clearUserData();
            return requester.putJSON(this.baseUrl + "/users", {}, headers);
        },
    });

    var AppointmentsPersister = Class.create({
        init: function (baseUrl) {
            this.baseUrl = baseUrl + "/appointments";
            this.headers = function () {
                return {
                    "X-accessToken": getAccessToken()
                }
            }
        },
        create: function (newAppointment) {
            return requester.postJSON(this.baseUrl, newAppointment, this.headers());
        },
        getAll: function () {
            return requester.getJSON(this.baseUrl + "/all", this.headers())
        },
        comming: function () {
            return requester.getJSON(this.baseUrl + "/comming", this.headers())
        },
        today: function () {
            return requester.getJSON(this.baseUrl + "/today", this.headers())
        },
        current: function () {
            return requester.getJSON(this.baseUrl + "/current", this.headers())
        },
        getByDate: function (date) {
            return requester.getJSON(this.baseUrl + "/?date=" + date, this.headers());
        }
    })

    var ListsPersisiter = Class.create({
        init: function (baseUrl) {
            this.baseUrl = baseUrl + "/lists";
            this.headers = function () {
                return {
                    "X-accessToken": getAccessToken()
                }
            }
        },
        create: function (lists) {
            return requester.postJSON(this.baseUrl, lists, this.headers());
        },
        getAll: function () {
            return requester.getJSON(this.baseUrl, this.headers());
        },
        getById: function (listId) {
            var url = this.baseUrl + "/" + listId + "/todos";
            return requester.getJSON(url, this.headers());
        },
        addToDo: function (listId, newToDo) {
            var url = this.baseUrl + "/" + listId + "/todos";
            return requester.postJSON(url, newToDo, this.headers());
        }
    })

    var TodosPersisiter = Class.create({
        init: function (baseUrl) {
            this.baseUrl = baseUrl + "/todos";
            this.headers = function () {
                return {
                    "X-accessToken": getAccessToken()
                }
            }
        },
        tickToggle: function (id) {
            return requester.putJSON(this.baseUrl + "/" + id, {}, this.headers())
        }
    })

    return {
        get: function (baseUrl) {
            return new DataPersister(baseUrl);
        }
    }
}());
