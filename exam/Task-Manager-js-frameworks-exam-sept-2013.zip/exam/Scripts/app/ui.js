﻿/// <reference path="../libs/_references.js" />
var todo = todo || {};

todo.ui = {
    init: function () {
        var self = this;       
    },

    handleError: function (err) {
        

        var message = err.message || err.Message || err.statusText || err.error;

        if (message == "error") {
            this.showErrorBox("Couldn't load file from server. Please go back and try again!");
            return;
        }

        if (!message && err.responseText) {
            var requestError = JSON.parse(err.responseText);
            message = requestError.Message || requestError.message;
        }

        if (!message) {
            debugger;
            alert("No message in error!");
        }

        this.showErrorBox(message);
    },

    showLoading: function () {
        jLoadingImage.show();
    },

    hideLoading: function () {
        jLoadingImage.hide();
    },

    showErrorBox: function (message) {
        var self = this;
        $("#error-text").text(message);
        $("#error-container").fadeIn(400);
        $("#error-close").on("click", function (ev) {
            self.hideErrorBox();
        });
    },

    hideErrorBox: function () {
        $("#error-container").fadeOut(400);
    },

    toggleNavigation: function (logged) {
        if (logged) {
            $("#login-nav-button").hide();
            $("#logout-nav-button").show();
            
        }
        else {
            $("#login-nav-button").show();
            $("#logout-nav-button").hide();
        }
    },
};