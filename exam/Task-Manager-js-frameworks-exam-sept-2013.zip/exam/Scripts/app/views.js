﻿/// <reference path="../libs/_references.js" />
var todo = todo || {};

todo.views = (function () {

    var rootUrl = "Scripts/partials/";
    var templates = {};

    function getTemplate(name) {
        var promise = new RSVP.Promise(function (resolve, reject) {
            if (templates[name]) {
                resolve(templates[name])
            }
            else {
                $.ajax({
                    url: rootUrl + name + ".html",
                    type: "GET",
                    success: function (templateHtml) {
                        templates[name] = templateHtml;
                        resolve(templateHtml);
                    },
                    error: function (err) {
                        reject(err)
                    }
                });
            }
        });
        return promise;
    }

    function getLayout() {
        return getTemplate("layout")
        .then(function (layoutHtml) {
            return new kendo.Layout(layoutHtml);
        });
    }

    function getLoginRegisterView() {
        return getTemplate("login-register-form");
    }

    function getHomeView() {
        return getTemplate("home");
    }

    function getProfileBoxView() {
        return getTemplate("profile-box");
    }

    function getAppointmentsAllView() {
        return getTemplate("appointments-all");
    }

    function getNewAppointmentView() {
        return getTemplate("new-appointment");
    }

    function getAllListsView() {
        return getTemplate("lists-all");
    }

    function getSingleListsView() {
        return getTemplate("list");
    }
    function getNewListView() {
        return getTemplate("new-list");
    } 

    return {
        getLayout: getLayout,
        getLoginRegisterView: getLoginRegisterView,
        getHomeView: getHomeView,
        getProfileBoxView: getProfileBoxView,
        getAppointmentsAllView: getAppointmentsAllView,
        newAppointment: getNewAppointmentView,
        allLists: getAllListsView,
        singleList: getSingleListsView,
        newList: getNewListView
    };
}());